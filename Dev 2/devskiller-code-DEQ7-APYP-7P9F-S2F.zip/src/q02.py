def solve(input_int: int) -> dict:
    return {}
